Vayasya Seva – font pack

Anek Latin        Display: headings and high-emphasis hierarchy (500–700)
Hind              Body and UI: reading, labels, interface copy (400–700)
JetBrains Mono    Data: identifiers, tables and aligned values (400–500)

Install
  Windows  Select the .ttf files, right-click, "Install for all users".
  macOS    Open the .ttf files and click "Install Font", or drop them into Font Book.

Variable fonts (AnekLatin-Variable, JetBrainsMono-Variable) expose every weight
from one file. Hind ships as five static weights.

All three families are published under the SIL Open Font License; the OFL.txt
in each folder is the licence. Fonts are unchanged from their Google Fonts release.

https://www.vayasyaseva.com/brand
