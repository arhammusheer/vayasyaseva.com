Vayasya Seva – logo kit

Files
  vayasya-seva-mark.svg                 Master mark, scalable (design, print, web)
  vayasya-seva-mark-{256,512,1024,2048} Transparent PNG (documents, slides, office tools)
  vayasya-seva-mark-1024-on-white.png   Plated on white
  vayasya-seva-mark-1024-on-navy.png    Plated on brand navy #0F172A
  icon-{16…512}.png                     Favicon, touch and manifest icons

Rules
  Keep clear space equal to the height of the mark's inner V on all sides.
  Do not recolour, retint, distort or gradient-map the mark.
  Over imagery, place the mark on a calm solid plate first.
  If it is too small to read, use a larger placement rather than forcing it smaller.
  Use the supplied files as-is; do not rebuild the mark.

Brand gold #DAA236 · Navy #0F172A · https://www.vayasyaseva.com/brand
